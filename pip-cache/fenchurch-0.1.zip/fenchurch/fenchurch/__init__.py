from os.path import join, exists
from django import http
from django.template import loader, TemplateDoesNotExist
from django.views.generic.base import TemplateView
from django.http import Http404
from django.conf import settings


class TemplateFinder(TemplateView):
    """
    A TemplateView that guesses the template name based on the
    url path or redirects if defined in redirects.txt.
    """

    def render_to_response(self, context, **response_kwargs):
        """
        Primarily, this injects the path into the legacy
        "level_n" context variables
        """

        path_list = [p for p in self.request.path.split('/') if p]
        for i, path, in enumerate(path_list):
            level = "level_%s" % str(i+1)
            context[level] = path
        template = self.get_template_names()

        return self.response_class(
            request=self.request,
            template=template,
            context=context,
            **response_kwargs
        )

    def load_redirects(self):
        """
        Load the module level variable redirect_list
        with a list of all available redirects
        """

        redirect_list = {}

        # Default redirect location
        redirect_file_path = settings.BASE_DIR + '/redirects.txt'

        # Read custom redirect location
        if hasattr(settings, 'FENCHURCH_REDIRECTS_PATH'):
            redirect_file_path = settings.FENCHURCH_REDIRECTS_PATH

        # If no redirects file, just return an empty dictionary
        if not exists(redirect_file_path):
            return redirect_list

        # Otherwise, read the file
        with open(redirect_file_path) as redirects:
            for redirect in redirects.readlines():
                # the format of a redirect line is:
                # src  dest  # comment
                parts = redirect.split('  ')
                if 2 <= len(parts) <= 3:
                    src = parts[0]
                    dest = parts[1]
                else:
                    # we have an invalid line
                    continue
                redirect_list[src] = dest

        return redirect_list

    def return_template(self, template_name):
        index = join(template_name, 'index.html')
        template = join(template_name + '.html')
        if self.__template_exists__(template):
            return template
        elif self.__template_exists__(index):
            return index

    def dispatch(self, request, *args, **kwargs):
        path = request.path[1:]
        self.template_name = self.return_template(path)
        redirects = self.load_redirects()
        redirect = redirects.get(path)

        if redirect:
            return http.HttpResponsePermanentRedirect(redirect)
        elif self.template_name:
            return super(TemplateFinder, self).dispatch(
                request, *args, **kwargs
            )
        else:
            raise Http404("Expected %s" % path)

    def __template_exists__(self, path):
        try:
            loader.get_template(path)
            return True
        except TemplateDoesNotExist:
            return False
