# -*- coding: utf-8 -*-
"""
Fenchurch
========

A Template rendering system for Django
"""

try:
    from setuptools import setup
except ImportError:
    from distutils.core import setup

setup(
    name='fenchurch',
    version='0.1',
    url='',
    license='BSD',
    author='Oatman',
    description='A template rending system for Django',
    packages=['fenchurch'],
    include_package_data=True,
    platforms='any'
)
