Fenchurch
===

Fenchurch passes matched URL paths through a standard view (TemplateFinder) to attempt to load the corresponding templates directly from URLs, without the need to write a view for each URL.

Fenchurch can optionally read a double-space-delimited list of basic URLs (without a preceding slash). By default, this file should live at `[BASE_DIR]/redirects.txt`.

Matching example
---

When Fenchurch parses a URL, it will look for templates in two corresponding locations, e.g.:

`http://example.com/parent/location/ => TEMPLATE_DIR/parent/location.html`

Or:

`http://example.com/parent/location/ => TEMPLATE_DIR/parent/location/index.html`

Installation
---

```
# Clone the repository
git clone git@bitbucket.org:nottrobin/fenchurch.git
# Pip install from the base directory
pip install ./fenchurch
```

Basic usage
---

For the most basic usage, simply include `TemplateFinder` in a URL match in your `urls.py` file, passing through the `template` argument:

``` python
# [app]/urls.py
from django.conf.urls import patterns, url
from fenchurch import TemplateFinder

urlpatterns = patterns('',
    url(r'^(?P<template>.*)$', TemplateFinder.as_view()),
)
```

Configuration
---

There are a couple of ways to configure Fenchurch:

### Templates

Fenchurch will use the default Django template loader to search for templates with the expected names, so the simplest way to configure the templates location is to use the default `TEMPLATE_DIRS` setting, e.g.:

``` python
# [app]/settings.py

TEMPLATE_DIRS = ( BASE_DIR + "/templates" )
```

### Redirects

You can change the location of the redirects file using the `FENCHURCH_REDIRECTS_PATH` setting:

``` python
# [app]/settings.py

FENCHURCH_REDIRECTS_PATH = BASE_DIR + '/redirects.txt'
```

Here's a short example redirects file:

``` python
# redirects.txt

# Redirect file format:
# source[space][space]destination[space][space]#[mandatory-comment]

parent/location  /location  # Simple internal redirect

location2  http://example.com  # External redirect
```
